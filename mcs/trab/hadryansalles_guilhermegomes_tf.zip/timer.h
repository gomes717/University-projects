#ifndef __TIMER__
#define __TIMER__

void TIMER2A_Init(void);
void TIMER0A_Init(void);
void TIMER0A_Stop();

#endif